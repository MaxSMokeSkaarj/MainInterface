/*
  Calc by MaxSMoke/KillSZ v3.4
*/
#define CALC_H
#ifdef CALC_H
#include <iostream>
#include <string>
#include <cmath>
#include "modules.h"
using namespace std;
void calc(){
int inf[] = {1,0};
go:
cout << "Choice:" << endl;
cout << "1)Sum" << endl;
cout << "2)Minus" << endl;
cout << "3)Multyply" << endl;
cout << "4)Divide" << endl;
cout << "5)Square" << endl;
cout << "6)Cube" << endl;
cout << "7)Root" << endl;
cout << "8)Sinus" << endl;
cout << "9)Cosinus" << endl;
cout << "10)Tangens" << endl;
cout << "11)Logarifm" << endl;
cout << "0-exit" << endl;
cout << "====================================" << endl;
cin >> inf[0];
if (inf[0] == 0) {
cout << "Exit to menu? 1)Yes, 2)No" << endl;
cout << "====================================" << endl;
cin >> inf[1];
if (inf[1] == 1) {
goto end;
} else if (inf[1] == 2) {
goto go;
} else {
cout << "Error 201" << endl;
cout << "====================================" << endl;
getch();
goto go;
}
} else if (inf[0] == 1) {
sum();
goto go;
} else if (inf[0] == 2) {
min();
goto go;
} else if (inf[0] == 3) {
multiply();
goto go;
} else if (inf[0] == 4) {
divide();
goto go;
} else if (inf[0] == 5) {
square();
goto go;
} else if (inf[0] == 6) {
cube();
goto go;
} else if (inf[0] == 7) {
root();
goto go;
} else if (inf[0] == 8) {
sin();
goto go;
} else if (inf[0] == 9) {
cos();
goto go;
} else if (inf[0] == 10) {
tan();
goto go;
} else if (inf[0] == 11) {
log();
goto go;
} else {
cout << "Error 202" << endl;
cout << "====================================" << endl;
getch();
goto go;
end:
getch();
}
}
#endif