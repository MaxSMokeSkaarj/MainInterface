/*
   Conv by MaxSMoke/KillSZ v0.1
*/
#define CONV_H
#ifdef CONV_H
#include <iostream>
#include <cstdlib>
#include "modules.h"
using namespace std;
void conv() {
int a,b;


















}
#endif