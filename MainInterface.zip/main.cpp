/*
  Main Interface by MaxSMoke/KillSZ v1.4
*/

#include <iostream>
#include <conio.h>
#include <cstdlib>
#include "calc.h"
#include "keygen.h"
#include "shell.h"
using namespace std;
int main() {
int a, b;
cout << "====================================" << endl;
cout << "Main Interfase v1.4 by KillSZ" << endl;
cout << "====================================" << endl;
again:
cout << "Choose:" << endl;
cout << "1)Calculator" << endl;
cout << "2)KeyGen" << endl;
cout << "3)SH/BaSh" << endl;
cout << "4)Converter" << endl;
cout << "5)OSMOS Project" << endl;
cout << "0-exit" << endl;
cout << "====================================" << endl;
cin >> a;
if (a == 1){
calc();
} else if (a == 2) {
KeyGen();
} else if (a == 3) {
shell();
} else if (a == 4) {
cout << "Coming Soon!" << endl;
cout << "====================================" << endl;
} else if (a == 5) {
cout << "Coming Soon!" << endl;
cout << "====================================" << endl;
} else if (a == 744327) {
//support();
} else if (a == 0) {
cout << "Exit? 1)Yes, 2)No" << endl;
cout << "====================================" << endl;
cin >> b;
if (b == 1) {
goto end;
} else if (b == 2) {
goto again;
} else {
cout << "Error 101" << endl;
cout << "====================================" << endl;;
getch();
}
} else {
cout << "Error 102" << endl;
cout << "====================================" << endl;;
getch();
}
goto again;
end:
return 0;
}